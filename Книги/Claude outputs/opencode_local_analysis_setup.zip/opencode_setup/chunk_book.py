#!/usr/bin/env python3
"""
chunk_book.py — режет текстовый файл книги на пронумерованные куски,
удобные для локальной модели с ограниченным контекстом (LM Studio + OpenCode).

Режет ПО ГРАНИЦАМ АБЗАЦЕВ (не разрывает предложения/цитаты), с небольшим
нахлёстом между кусками, чтобы мысль на стыке не терялась.

Использование:
    python3 chunk_book.py "книга.txt" --outdir "книга_chunks" --size 28000 --overlap 500

Параметры по умолчанию (28000 симв. на кусок) рассчитаны так, чтобы кусок
+ системный промпт + место под ответ уверенно помещались в контекст 65536
токенов даже для кириллического текста (у кириллицы обычно ~2-2.5 символа
на токен, то есть кусок в 28000 символов — это примерно 11 000-14 000
токенов на входе).
"""
import argparse
import os
import re
import json


def split_into_paragraphs(text: str) -> list[str]:
    # Разбиваем по пустым строкам (стандартный разделитель абзацев),
    # но не теряем сами разделители — они пригодятся при склейке.
    parts = re.split(r"(\n\s*\n)", text)
    paragraphs = []
    buf = ""
    for part in parts:
        buf += part
        if part.strip() == "" and buf.strip() != "":
            paragraphs.append(buf)
            buf = ""
    if buf.strip():
        paragraphs.append(buf)
    return paragraphs if paragraphs else [text]


def chunk_book(text: str, target_size: int, overlap: int) -> list[str]:
    paragraphs = split_into_paragraphs(text)
    chunks = []
    current = ""
    for para in paragraphs:
        if len(current) + len(para) > target_size and current.strip():
            chunks.append(current)
            # нахлёст: берём хвост предыдущего куска символов на overlap,
            # чтобы не терять контекст на стыке
            tail = current[-overlap:] if overlap > 0 else ""
            current = tail + para
        else:
            current += para
    if current.strip():
        chunks.append(current)
    return chunks


def main():
    ap = argparse.ArgumentParser(description="Режет книгу на куски для локальной модели")
    ap.add_argument("book_file", help="Путь к .txt файлу с полным текстом книги")
    ap.add_argument("--outdir", default=None, help="Куда сохранить куски (по умолчанию <имя_книги>_chunks)")
    ap.add_argument("--size", type=int, default=28000, help="Целевой размер куска в символах (по умолчанию 28000)")
    ap.add_argument("--overlap", type=int, default=500, help="Нахлёст между кусками в символах (по умолчанию 500)")
    args = ap.parse_args()

    with open(args.book_file, encoding="utf-8", errors="replace") as f:
        text = f.read()

    base = os.path.splitext(os.path.basename(args.book_file))[0]
    outdir = args.outdir or f"{base}_chunks"
    os.makedirs(outdir, exist_ok=True)

    chunks = chunk_book(text, args.size, args.overlap)

    manifest = {"source": args.book_file, "total_chars": len(text), "chunk_count": len(chunks), "chunks": []}
    for i, chunk in enumerate(chunks, start=1):
        fname = f"chunk_{i:03d}.txt"
        fpath = os.path.join(outdir, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(chunk)
        manifest["chunks"].append({"file": fname, "chars": len(chunk)})
        print(f"  {fname}: {len(chunk)} символов (~{len(chunk)//2200}K токенов)")

    with open(os.path.join(outdir, "_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print(f"\nГотово: {len(chunks)} кусков в папке '{outdir}/'")
    print(f"Исходный текст: {len(text)} символов")


if __name__ == "__main__":
    main()
