#!/usr/bin/env bash
# run_book_analysis.sh — прогоняет все куски книги через локальную модель
# (LM Studio через OpenCode-агента book-chunk-extractor) и склеивает
# результат в один файл, готовый для передачи Claude на финальную сборку.
#
# Использование:
#   ./run_book_analysis.sh "книга_chunks" "книга_РЕЗУЛЬТАТ.md"
#
# Перед первым запуском один раз в отдельном терминале запустите сервер:
#   opencode serve
# (это ускоряет обработку — без --attach каждый вызов будет заново
# поднимать opencode с нуля, что на десятках кусков ощутимо медленнее)

set -euo pipefail

CHUNKS_DIR="${1:?Укажите папку с кусками (результат chunk_book.py)}"
OUT_FILE="${2:?Укажите путь для итогового файла}"
ATTACH_URL="${OPENCODE_ATTACH:-http://localhost:4096}"

if [ ! -d "$CHUNKS_DIR" ]; then
  echo "Папка $CHUNKS_DIR не найдена. Сначала запустите chunk_book.py"
  exit 1
fi

> "$OUT_FILE"

CHUNK_FILES=$(ls "$CHUNKS_DIR"/chunk_*.txt | sort)
TOTAL=$(echo "$CHUNK_FILES" | wc -l)
N=0

for chunk in $CHUNK_FILES; do
  N=$((N+1))
  echo "[$N/$TOTAL] Обрабатываю $chunk ..."

  RESULT=$(opencode run \
    --agent book-chunk-extractor \
    --attach "$ATTACH_URL" \
    --file "$chunk" \
    "Извлеки структурированные заметки из этого куска книги." 2>&1) || {
      echo "  ! Ошибка на $chunk — пропускаю, разберитесь вручную позже" >&2
      echo -e "\n## $(basename "$chunk") — ОШИБКА ОБРАБОТКИ\n" >> "$OUT_FILE"
      continue
    }

  {
    echo ""
    echo "# ==== $(basename "$chunk") ===="
    echo ""
    echo "$RESULT"
    echo ""
  } >> "$OUT_FILE"
done

echo ""
echo "Готово: $N кусков обработано, результат в $OUT_FILE"
echo "Дальше — отдайте этот файл Claude на финальную сборку разбора и проверку цитат."
